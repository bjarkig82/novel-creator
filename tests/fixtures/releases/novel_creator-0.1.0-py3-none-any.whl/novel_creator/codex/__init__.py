"""Replaceable Codex integration resources."""
